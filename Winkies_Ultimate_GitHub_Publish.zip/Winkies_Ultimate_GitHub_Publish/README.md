# Winkies Ultimate

## Publish with GitHub Pages

1. Create a GitHub repository named `winkies-ultimate`.
2. Upload `index.html` to the repository's top level (same folder as this README).
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose branch `main` and folder `/(root)`, then click **Save**.
6. Wait for the Pages deployment to finish. The site URL will be shown in Settings → Pages and usually looks like `https://YOUR-USERNAME.github.io/winkies-ultimate/`.

## Multiplayer status

This bundle is the current single-file game prepared for web hosting. It does **not** yet implement real internet multiplayer. GitHub Pages hosts static files only; a multiplayer mode needs connection/signaling code and a protocol to synchronize match state between players. Do not advertise the game as online multiplayer until that has been implemented and tested on two separate devices.
